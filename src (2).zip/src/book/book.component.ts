import { Component } from '@angular/core';
import { IBook } from "./book";

@Component({
  selector: 'bk',
  templateUrl: './book.component.html',
  //styleUrls: ['./form.component.css'],
  //styleUrls: ['./app.component.css']
})
export class BookComponent{

  Title:string="bubblegums and candies";
   imgWidth:number=400;
  imgHeight:number=180;

      books:IBook[]=[
  
   {id:1,Title:"bubblegums and candies", catagory:"Fiction",Author:"Preeti Shenoy",  Description:5},
   {id:2,Title:"4th of July", catagory:"Fiction",Author:"James Patterson",  Description:5},
   {id:3,Title:"A Bend in the Road", catagory:"Fiction",Author:"Nicholas Sparks",  Description:5},
   {id:4,Title:"A Case of Need", catagory:"fiction",Author:"Michael Crichton",  Description:5},
   {id:5,Title:"A Far Horizon", catagory:"Fiction",Author:"Meira chand",  Description:5},
   {id:6,Title:"A prisoner of birth", catagory:"Fiction",Author:"Jeffrey Archer",  Description:5},
   {id:7,Title:"A Fine Family", catagory:"Fiction",Author:"Gurucharan Das",  Description:5},
   
   
 
  
 ];

}
