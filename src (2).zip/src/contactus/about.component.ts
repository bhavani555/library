import { Component } from '@angular/core';

@Component({
  selector: 'ab',
  templateUrl: './about.component.html',
styleUrls: ['./about.component.css'],
  //styleUrls: ['./app.component.css']
})
export class AboutComponent{
  
  

}
